require("./all/module.js")

global.owner = "6285861398259"
global.dev = "6283842155959"
global.namabot = "Pushkontak By denz" 
global.della = "DENZ HOSTING"
global.namaowner = "della Dev"
global.versi = "Versi script 1.0.2"
global.idsaluran = "120363349892708976@newsletter"
global.linkgc = 'https://chat.whatsapp.com/CGWMk08sm3BKb4EantTFZY'
global.linksaluran = "https://whatsapp.com/channel/0029VagTCBr1iUxQVNZbMA3I"
global.linkyt = "https://youtube.com/@denzstorex"


global.packname = "WhatsApo Bot denz"
global.author = "Denz BOTZ"
global.list =`*List harga panel denz*
*➬* 1gb   ➩   1k
*➬* 2gb   ➩   2k
*➬* 3gb   ➩   3k
*➬* 4gb   ➩   4k
*➬* 5gb   ➩   5k
*➬* 6gb   ➩   6k
*➬* 7gb   ➩   7k
*➬* 8gb   ➩   8k
*➬* 9gb   ➩   9k
*➬* unli   ➩   10k
        ➥ *Open adp↓*
➬ *Admin Panel* 10k
        ➥ *Open Reseller panel↓*
➬ *Reseller panel* 15k
        ➥  *Open Owner panel↓*
➬ *Owner panel* 20k
*Buy?* *Pm* di bawah
`
global.autoread = false 
global.anticall = true

/*~~~~~~~~~~ SETTING IMAGE ~~~~~~~~~~~*/
global.image = "./media/denz.png"
global.image2 = './media/denz.png'
global.thumbnail = "./media/denz.png"

/*~~~~~~~~~~ SETTINGS PANEL ~~~~~~~~~~*/
global.egg = "15"
global.loc = "1"
global.domain = "https://demonszz-store.kedai-panel.me"
global.apikey = "ptla_5Fm5oFOrPeSr5kdZf7S82r7b6B5ef7jfGDeoZtglvTM"
global.capikey = "ptlc_4UPder7x5gyz50QZt9FNzwcKPDZMYAIV0xL0dVsIBTq"

/*~~~~~~~~~ SETTING MESSAGE ~~~~~~~~~~*/
global.msg = {
"error": "Fitur ini blm di fix, hubungi dev dengan perintah help",
"done": "Sukses..", 
"wait": "Sek", 
"group": "Keknya ini bukan grup deh😅", 
"private": "Ko cet di grup? bukanya ini buat di private kita", 
"admin": "Adminin dulu bot nya", 
"adminbot": "Jadiin admin dulu gw😓", 
"owner": "Fitur Ini Buat pengguna bot denz", 
"developer": "Fitur ini buat denz😓❗"
}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})